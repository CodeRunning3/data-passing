# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse
from django.shortcuts import render


def homePage(request):
    return render(request, "index.html")



import warnings

warnings.filterwarnings("ignore")
import re  # for hyper links removal
from textblob import TextBlob  # for spelling correction
import contractions  # for appling contractions
import nltk  # different work link stop word
from nltk.tokenize import word_tokenize  # tokenization
from nltk.corpus import stopwords  # stopwords
from nltk.corpus import wordnet  # lemmatization (POS tags)
from nltk.stem import WordNetLemmatizer  # word lematization
import joblib  # for model loaing(e.g. SVM, SGB, CNN)
from flask import Flask, render_template, url_for, request, redirect

",".join(stopwords.words("english"))
stopward_data = set(stopwords.words("english"))


def get_wordnet_pos(word):  # POS=PARTS OF SPEECH....
    tag = nltk.pos_tag([word])[0][1][0].upper()
    tag_dict = {
        "J": wordnet.ADJ,
        "N": wordnet.NOUN,
        "V": wordnet.VERB,
        "R": wordnet.ADV,
    }
    return tag_dict.get(tag, wordnet.NOUN)


lemmatizer = WordNetLemmatizer()


def remove_stop(x):
    return " , ".join(
        [word for word in str(x).split() if len(word) > 2 if word not in stopward_data]
    )


def test_data_preprocessing(test_data1):
    test_data1 = test_data1.lower()
    test_data1 = re.compile(
        r"(http|https|ftp|ssh)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?"
    ).sub("", test_data1)
    test_data1 = re.compile(r"<.*?>").sub("", test_data1)  # remove tags
    test_data1 = TextBlob(test_data1).correct()  # Speeling correction
    test_data1 = "".join(
        filter(lambda x: not x.isdigit(), test_data1)
    )  # remove numbers
    test_data1 = contractions.fix(test_data1)  # contraction
    test_data1 = remove_stop(test_data1)  # stop word removal
    test_data1 = re.compile(r"[^\w\s]").sub(
        "", test_data1
    )  # '[^\w\s]',''   this convert all puntuations, underscores, alphabets to null(not of word characters and space)
    test_data1 = word_tokenize(test_data1)  # Tokenization
    test_data1 = [
        lemmatizer.lemmatize(w, get_wordnet_pos(w)) for w in test_data1
    ]  # Lemmatization
    return test_data1




from django.template import loader


def result(request):
    if request.method=="POST":
        namee = request.POST['name']
        namee2 = test_data_preprocessing(namee)
        return render(
        request,
        "index.html",
        {"name":namee2}
        )
        return render(
        request,
        "index.html"
        )

